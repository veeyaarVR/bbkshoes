package com.veeyaar.myscanner.view.activity;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.veeyaar.myscanner.R;
import com.veeyaar.myscanner.view.adapter.ObjectListAdapter;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ListActivity extends BaseActivity {

    @BindView(R.id.recy_objects)
    RecyclerView recyObjects;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        ButterKnife.bind(this);
        setUpRecy();
    }

    private void setUpRecy() {
        Toast.makeText(this, "Scan buttoan pressed", Toast.LENGTH_SHORT).show();
        ObjectListAdapter adapter = new ObjectListAdapter(this);
        recyObjects.setAdapter(adapter);
    }

}
