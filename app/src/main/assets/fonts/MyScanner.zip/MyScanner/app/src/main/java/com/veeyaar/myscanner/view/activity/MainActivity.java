package com.veeyaar.myscanner.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.veeyaar.myscanner.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends BaseActivity implements View.OnClickListener {

    @BindView(R.id.btn_scan)
    Button btnScan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        btnScan.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn_scan) {
            goToScanScreen();
        }
    }

    private void showErrorToast() {
        Toast.makeText(this, "Something went wrong!", Toast.LENGTH_SHORT).show();
    }

    private void goToScanScreen() {
        Intent intent = new Intent(this, SimpleScannerActivity.class);
        startActivity(intent);
    }


}
